/*
 * Ava Fritz
 * Introduction to Programming Using Java
 * Assignment 1
 */

// Outputs "JAVA"
public class Assignment1
{
    public static void main( String [] args )
    {
        System.out.print("\n\n\n\n\n\n");
        System.out.print("\tJ\tA\tV\t\b\bV\t\t\b\bA\n");
        System.out.print("\tJ\t\bA A\t V\t\b\b\bV\t\t\b\b\bA A\n");
        System.out.print("\t\b\b\b\b\b J\tJ\t\b\bAAAAA\t  V V\t\t\b\b\b\bAAAAA\n");
        System.out.print("\t\b\b\bJ J\t\b\b\bA\t\t\b\b\b\b\bA\t\t\b\b\b\b\bV\t\t\b\b\b\b\bA\t A\n\n\n");
    }
}