/*
 * Ava Fritz
 * 07/24/2023
 * This interface executes the rotateObject method
 * 
 * Assumptions:
 * 1. Class of object has a rotateObject method.
 */
public interface Rotatable
{
    void rotateObject();   
}
