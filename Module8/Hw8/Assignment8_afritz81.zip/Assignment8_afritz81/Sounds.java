/*
 * Ava Fritz
 * 07/24/2023
 * This interface executes the playSound method
 * 
 * Assumptions:
 * 1. Class of object has a playSound method.
 */
public interface Sounds
{
    void playSound();   
}
